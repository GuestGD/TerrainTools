bl_info = {
    "name": "Simple Attribute Adder",
    "author": "Your Name",
    "version": (1, 0, 0),
    "blender": (3, 0, 0),
    "location": "View3D > Sidebar > Attr",
    "description": "Add a custom attribute to a chosen object or to every object in a collection",
    "category": "Object",
}

import bpy
from bpy.props import (
    EnumProperty,
    StringProperty,
    FloatProperty,
    IntProperty,
    BoolProperty,
    FloatVectorProperty,
)
from bpy.types import Panel, Operator, PropertyGroup

# ------------------------------------------------------------------
# Utilities
# ------------------------------------------------------------------
def target_items(self, context):
    """Populate the second drop-down dynamically."""
    if self.target_type == 'OBJECT':
        return [(obj.name, obj.name, "") for obj in context.scene.objects if obj.type == 'MESH']
    else:  # COLLECTION
        return [(col.name, col.name, "") for col in bpy.data.collections]

# ------------------------------------------------------------------
# Property Group (all UI settings live here)
# ------------------------------------------------------------------
class SAA_Props(PropertyGroup):
    target_type: EnumProperty(
        name="Target",
        items=[('OBJECT', "Single Object", ""), ('COLLECTION', "Collection", "")],
        description="Add attribute to one object or to every object in a collection",
    )

    target: EnumProperty(
        name="Object / Collection",
        items=target_items,
        description="Choose the object or collection to receive the attribute",
    )

    attr_name: StringProperty(name="Attribute Name", default="MyAttr")
    domain: EnumProperty(
        name="Domain",
        items=[
            ('POINT', "Point", ""),
            ('EDGE', "Edge", ""),
            ('FACE', "Face", ""),
            ('CORNER', "Corner", ""),
        ],
        default='POINT',
    )
    data_type: EnumProperty(
        name="Type",
        items=[
            ('FLOAT', "Float", ""),
            ('INT', "Integer", ""),
            ('BOOLEAN', "Boolean", ""),
            ('FLOAT_VECTOR', "Vector", ""),
            ('FLOAT_COLOR', "Color", ""),
        ],
        default='FLOAT',
        description="Data-type of the attribute",
    )

    # Default-value widgets (only the relevant one is shown in the UI)
    default_float: FloatProperty(name="Value", default=0.0)
    default_int: IntProperty(name="Value", default=0)
    default_bool: BoolProperty(name="Value", default=False)
    default_vector: FloatVectorProperty(name="Value", size=3, default=(0.0, 0.0, 0.0))
    default_color: FloatVectorProperty(
        name="Value", subtype='COLOR', size=4, default=(1.0, 1.0, 1.0, 1.0), min=0.0, max=1.0
    )

# ------------------------------------------------------------------
# Operator
# ------------------------------------------------------------------
class SAA_OT_add_attribute(Operator):
    bl_idname = "saa.add_attribute"
    bl_label = "Add / Update Attribute"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return context.scene.saa_props.target != ""

    def execute(self, context):
        props = context.scene.saa_props
        targets = []

        if props.target_type == 'OBJECT':
            ob = bpy.data.objects.get(props.target)
            if ob and ob.type == 'MESH':
                targets.append(ob)
        else:  # COLLECTION
            col = bpy.data.collections.get(props.target)
            if col:
                targets = [o for o in col.objects if o.type == 'MESH']

        if not targets:
            self.report({'WARNING'}, "No mesh objects found")
            return {'CANCELLED'}

        # Pick the correct default value
        default = {
            'FLOAT': props.default_float,
            'INT': props.default_int,
            'BOOLEAN': props.default_bool,
            'FLOAT_VECTOR': props.default_vector,
            'FLOAT_COLOR': props.default_color,
        }[props.data_type]

        for ob in targets:
            me = ob.data
            # Remove if already present, then add fresh
            if props.attr_name in me.attributes:
                me.attributes.remove(me.attributes[props.attr_name])
            attr = me.attributes.new(
                name=props.attr_name,
                type=props.data_type,
                domain=props.domain,
            )
            # Fill with default value (simple fill)
            if props.data_type in {'FLOAT', 'INT', 'BOOLEAN'}:
                attr.data.foreach_set("value", [default] * len(attr.data))
            elif props.data_type == 'FLOAT_VECTOR':
                flat = list(default) * len(attr.data)
                attr.data.foreach_set("vector", flat)
            elif props.data_type == 'FLOAT_COLOR':
                flat = list(default) * len(attr.data)
                attr.data.foreach_set("color", flat)
            me.update()

        self.report({'INFO'}, f"Attribute '{props.attr_name}' added to {len(targets)} object(s)")
        return {'FINISHED'}

# ------------------------------------------------------------------
# Panel (3D-view sidebar)
# ------------------------------------------------------------------
class SAA_PT_panel(Panel):
    bl_label = "Simple Attribute Adder"
    bl_idname = "SAA_PT_panel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Attr"

    def draw(self, context):
        layout = self.layout
        props = context.scene.saa_props

        layout.prop(props, "target_type")
        layout.prop(props, "target")

        box = layout.box()
        box.prop(props, "attr_name")
        box.prop(props, "domain")
        box.prop(props, "data_type")

        # Show only the widget that matches the chosen type
        dt = props.data_type
        if dt == 'FLOAT':
            box.prop(props, "default_float")
        elif dt == 'INT':
            box.prop(props, "default_int")
        elif dt == 'BOOLEAN':
            box.prop(props, "default_bool")
        elif dt == 'FLOAT_VECTOR':
            box.prop(props, "default_vector")
        elif dt == 'FLOAT_COLOR':
            box.prop(props, "default_color")

        layout.operator("saa.add_attribute", icon='ADD')

# ------------------------------------------------------------------
# Registration
# ------------------------------------------------------------------
classes = (SAA_Props, SAA_OT_add_attribute, SAA_PT_panel)

def register():
    for cls in classes:
        bpy.utils.register_class(cls)
    bpy.types.Scene.saa_props = bpy.props.PointerProperty(type=SAA_Props)

def unregister():
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)
    del bpy.types.Scene.saa_props

if __name__ == "__main__":
    register()