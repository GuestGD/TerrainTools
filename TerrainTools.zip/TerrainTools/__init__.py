bl_info = {
    "name": "Terrain Chunk Divider + LOD",
    "author": "Your Name",
    "version": (1, 4, 0),
    "blender": (3, 0, 0),
    "location": "Properties > Object",
    "description": "Divides terrain meshes into chunks, creates border meshes, transfers custom normals, generates LODs",
    "warning": "",
    "doc_url": "",
    "category": "Object",
}

import bpy
import bmesh
from mathutils import Vector
from bpy.props import (
    StringProperty, BoolProperty, IntProperty, FloatProperty,
    EnumProperty, PointerProperty, CollectionProperty
)
from bpy.types import PropertyGroup, UIList, Operator, Panel

# ------------------------------------------------------------------
# Utilities
# ------------------------------------------------------------------
def calculate_bounds(obj):
    min_co = Vector((float('inf'),) * 3)
    max_co = -min_co.copy()
    for v in obj.data.vertices:
        v_co = obj.matrix_world @ v.co
        min_co = Vector(map(min, zip(min_co, v_co)))
        max_co = Vector(map(max, zip(max_co, v_co)))
    return min_co, max_co

def get_collections(self, context):
    return [(col.name, col.name, "") for col in bpy.data.collections]

# ------------------------------------------------------------------
# Property Groups
# ------------------------------------------------------------------
class LODLevel(PropertyGroup):
    ratio: FloatProperty(name="Ratio", default=0.5, min=0.01, max=1.0)

class TerrainChunkProperties(PropertyGroup):
    terrain_object: PointerProperty(
        name="Terrain Object",
        type=bpy.types.Object,
        poll=lambda self, obj: obj.type == 'MESH'
    )
    x_chunks: IntProperty(name="X Chunks", default=2, min=1, max=100)
    y_chunks: IntProperty(name="Y Chunks", default=2, min=1, max=100)
    rename_chunks: BoolProperty(name="Rename Chunks", default=True)
    select_chunks: BoolProperty(name="Select Chunks", default=True)
    border_mesh_name: StringProperty(name="Border Mesh Name", default="Terrain_Borders")
    normals_source_object: PointerProperty(
        name="Normals Source",
        type=bpy.types.Object,
        poll=lambda self, obj: obj.type == 'MESH'
    )
    normals_collection: EnumProperty(
        name="Target Collection",
        items=get_collections
    )
    normals_modifier_name: StringProperty(name="Modifier Name", default="NormalsTransfer")

    # LOD properties
    lod_collection: EnumProperty(name="Target Collection", items=get_collections)
    lod_pattern: StringProperty(name="Name Pattern", default="terrainChunk")
    lod_levels: CollectionProperty(type=LODLevel)
    lod_levels_index: IntProperty(default=0)
    
    # New overlapping borders feature
    use_overlapping_borders: BoolProperty(
        name="Use Overlapping Borders", 
        default=False,
        description="Keep triangles on borders so adjacent chunks have overlapping geometry"
    )

# ------------------------------------------------------------------
# UI Lists
# ------------------------------------------------------------------
class TERRAIN_UL_lod_levels(UIList):
    def draw_item(self, _c, layout, _d, item, _i, _a, _b):
        layout.prop(item, "ratio", text="")

# ------------------------------------------------------------------
# Operators  (core features)
# ------------------------------------------------------------------
class DivideTerrainOperator(Operator):
    bl_idname = "terrain.divide_into_chunks"
    bl_label = "Divide Terrain"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        props = context.scene.terrain_chunk_props
        if not props.terrain_object:
            self.report({'ERROR'}, "No terrain object selected!")
            return {'CANCELLED'}
        
        obj = props.terrain_object
        
        if props.use_overlapping_borders:
            return self.divide_with_overlapping_borders(context, obj, props)
        else:
            return self.divide_original_method(context, obj, props)

    def divide_original_method(self, context, obj, props):
        """Original division method using face selection and separation"""
        original_selection = context.selected_objects.copy()
        original_active = context.view_layer.objects.active
        try:
            min_co, max_co = calculate_bounds(obj)
            size = max_co - min_co
            chunk_size_x = size.x / props.x_chunks
            chunk_size_y = size.y / props.y_chunks
            context.view_layer.objects.active = obj
            obj.select_set(True)
            bpy.ops.object.mode_set(mode='EDIT')
            bm = bmesh.from_edit_mesh(obj.data)
            bm.faces.ensure_lookup_table()
            chunk_objects = []
            for i in range(props.x_chunks):
                for j in range(props.y_chunks):
                    x_min = min_co.x + i * chunk_size_x
                    x_max = x_min + chunk_size_x
                    y_min = min_co.y + j * chunk_size_y
                    y_max = y_min + chunk_size_y
                    bpy.ops.mesh.select_all(action='DESELECT')
                    for face in bm.faces:
                        face_center = obj.matrix_world @ face.calc_center_median()
                        if (x_min <= face_center.x <= x_max) and (y_min <= face_center.y <= y_max):
                            face.select = True
                    selected_faces = [f for f in bm.faces if f.select]
                    if selected_faces:
                        bmesh.update_edit_mesh(obj.data)
                        bpy.ops.mesh.separate(type='SELECTED')
                        bpy.ops.object.mode_set(mode='OBJECT')
                        new_obj = context.selected_objects[-1]
                        if props.rename_chunks:
                            new_obj.name = f"{obj.name}_chunk_{i}_{j}"
                        chunk_objects.append(new_obj)
                        obj.select_set(True)
                        context.view_layer.objects.active = obj
                        bpy.ops.object.mode_set(mode='EDIT')
                        bm = bmesh.from_edit_mesh(obj.data)
                        bm.faces.ensure_lookup_table()
            bpy.ops.object.mode_set(mode='OBJECT')
            if props.select_chunks and chunk_objects:
                bpy.ops.object.select_all(action='DESELECT')
                for chunk in chunk_objects:
                    chunk.select_set(True)
                context.view_layer.objects.active = chunk_objects[0]
            self.report({'INFO'}, f"Terrain divided into {props.x_chunks * props.y_chunks} chunks")
            return {'FINISHED'}
        except Exception as e:
            bpy.ops.object.select_all(action='DESELECT')
            for obj in original_selection:
                obj.select_set(True)
            context.view_layer.objects.active = original_active
            self.report({'ERROR'}, f"Operation failed: {str(e)}")
            return {'CANCELLED'}

    def divide_with_overlapping_borders(self, context, obj, props):
        """New method that creates overlapping borders between chunks"""
        original_selection = context.selected_objects.copy()
        original_active = context.view_layer.objects.active
        
        try:
            min_co, max_co = calculate_bounds(obj)
            size = max_co - min_co
            chunk_size_x = size.x / props.x_chunks
            chunk_size_y = size.y / props.y_chunks
            
            new_objects = []
            
            for i in range(props.x_chunks):
                for j in range(props.y_chunks):
                    x_min = min_co.x + i * chunk_size_x
                    x_max = x_min + chunk_size_x
                    y_min = min_co.y + j * chunk_size_y
                    y_max = y_min + chunk_size_y
                    
                    # Create a full copy of the original object
                    new_mesh = obj.data.copy()
                    new_obj = bpy.data.objects.new(f"{obj.name}_chunk_{i}_{j}", new_mesh)
                    context.collection.objects.link(new_obj)
                    
                    # Switch to edit mode on new object
                    bpy.ops.object.select_all(action='DESELECT')
                    new_obj.select_set(True)
                    context.view_layer.objects.active = new_obj
                    bpy.ops.object.mode_set(mode='EDIT')
                    bm = bmesh.from_edit_mesh(new_obj.data)
                    bm.faces.ensure_lookup_table()
                    
                    # Deselect all, then select faces to KEEP (any vertex in bounds)
                    bpy.ops.mesh.select_all(action='SELECT')  # Start with all selected
                    keep_faces = []
                    for face in bm.faces:
                        for loop in face.loops:
                            v = loop.vert
                            co = new_obj.matrix_world @ v.co  # World space
                            if (x_min <= co.x <= x_max) and (y_min <= co.y <= y_max):
                                keep_faces.append(face)
                                break
                    
                    # Deselect faces not in keep list
                    for face in bm.faces:
                        face.select = face in keep_faces
                    
                    # Delete unselected faces
                    bmesh.ops.delete(bm, geom=[f for f in bm.faces if not f.select], context='FACES')
                    bmesh.update_edit_mesh(new_obj.data)
                    
                    # Finalize
                    bpy.ops.object.mode_set(mode='OBJECT')
                    new_objects.append(new_obj)
            
            # Clean up original object
            bpy.data.objects.remove(obj)
            
            # Select new chunks
            if props.select_chunks and new_objects:
                bpy.ops.object.select_all(action='DESELECT')
                for chunk in new_objects:
                    chunk.select_set(True)
                context.view_layer.objects.active = new_objects[0]
            
            self.report({'INFO'}, f"Created {len(new_objects)} chunks with overlapping borders")
            return {'FINISHED'}
            
        except Exception as e:
            bpy.ops.object.select_all(action='DESELECT')
            for obj in original_selection:
                obj.select_set(True)
            context.view_layer.objects.active = original_active
            self.report({'ERROR'}, f"Overlapping borders operation failed: {str(e)}")
            return {'CANCELLED'}

class SelectTerrainObjectOperator(Operator):
    bl_idname = "terrain.select_terrain_object"
    bl_label = "Select Terrain Object"

    def execute(self, context):
        props = context.scene.terrain_chunk_props
        if not props.terrain_object:
            self.report({'WARNING'}, "No terrain object selected!")
            return {'CANCELLED'}
        bpy.ops.object.select_all(action='DESELECT')
        props.terrain_object.select_set(True)
        context.view_layer.objects.active = props.terrain_object
        self.report({'INFO'}, f"Selected terrain object: {props.terrain_object.name}")
        return {'FINISHED'}

class CreateBorderMeshOperator(Operator):
    bl_idname = "terrain.create_border_mesh"
    bl_label = "Create Border Mesh"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        props = context.scene.terrain_chunk_props
        chunks = [obj for obj in context.selected_objects if obj.type == 'MESH']
        if not chunks:
            self.report({'WARNING'}, "No mesh objects selected")
            return {'CANCELLED'}
        original_selection = context.selected_objects.copy()
        original_active = context.view_layer.objects.active
        try:
            border_mesh = bpy.data.meshes.new(props.border_mesh_name)
            border_obj = bpy.data.objects.new(props.border_mesh_name, border_mesh)
            context.collection.objects.link(border_obj)
            border_bm = bmesh.new()
            for chunk in chunks:
                bm = bmesh.new()
                bm.from_mesh(chunk.data)
                bm.transform(chunk.matrix_world)
                border_edges = [e for e in bm.edges if len(e.link_faces) == 1]
                for edge in border_edges:
                    for face in edge.link_faces:
                        new_verts = [border_bm.verts.new(v.co) for v in face.verts]
                        border_bm.faces.new(new_verts)
                bm.free()
            border_bm.to_mesh(border_mesh)
            border_bm.free()
            bpy.ops.object.select_all(action='DESELECT')
            border_obj.select_set(True)
            context.view_layer.objects.active = border_obj
            self.report({'INFO'}, f"Created border mesh with {len(border_mesh.polygons)} faces")
            return {'FINISHED'}
        except Exception as e:
            bpy.ops.object.select_all(action='DESELECT')
            for obj in original_selection:
                obj.select_set(True)
            context.view_layer.objects.active = original_active
            self.report({'ERROR'}, f"Border creation failed: {str(e)}")
            return {'CANCELLED'}

class AddNormalsTransferOperator(Operator):
    bl_idname = "terrain.add_normals_transfer"
    bl_label = "Add Normals Transfer"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        props = context.scene.terrain_chunk_props
        if not props.normals_source_object:
            self.report({'ERROR'}, "No normals source selected!")
            return {'CANCELLED'}
        if not props.normals_collection:
            self.report({'ERROR'}, "No target collection selected!")
            return {'CANCELLED'}
        source_obj = props.normals_source_object
        target_collection = bpy.data.collections.get(props.normals_collection)
        if not target_collection:
            self.report({'ERROR'}, f"Collection '{props.normals_collection}' not found")
            return {'CANCELLED'}
        modified_count = 0
        for target_obj in target_collection.objects:
            if target_obj.type != 'MESH':
                continue
            for mod in target_obj.modifiers:
                if mod.name == props.normals_modifier_name and mod.type == 'DATA_TRANSFER':
                    target_obj.modifiers.remove(mod)
                    break
            mod = target_obj.modifiers.new(name=props.normals_modifier_name, type='DATA_TRANSFER')
            mod.use_vert_data = False
            mod.use_edge_data = False
            mod.use_poly_data = False
            mod.use_loop_data = True
            mod.object = source_obj
            mod.data_types_loops = {'CUSTOM_NORMAL'}
            mod.loop_mapping = 'POLYINTERP_NEAREST'
            mod.mix_mode = 'REPLACE'
            mod.mix_factor = 1.0
            mod.use_object_transform = True
            modified_count += 1
        self.report({'INFO'}, f"Added normals transfer to {modified_count} objects in '{props.normals_collection}'")
        return {'FINISHED'}

class SelectNormalsSourceOperator(Operator):
    bl_idname = "terrain.select_normals_source"
    bl_label = "Select Normals Source"

    def execute(self, context):
        props = context.scene.terrain_chunk_props
        if not props.normals_source_object:
            self.report({'WARNING'}, "No normals source selected!")
            return {'CANCELLED'}
        bpy.ops.object.select_all(action='DESELECT')
        props.normals_source_object.select_set(True)
        context.view_layer.objects.active = props.normals_source_object
        self.report({'INFO'}, f"Selected normals source: {props.normals_source_object.name}")
        return {'FINISHED'}

# ------------------------------------------------------------------
# LOD Operators
# ------------------------------------------------------------------
class GenerateLODOperator(Operator):
    bl_idname = "terrain.generate_lods"
    bl_label = "Generate LODs"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        props = context.scene.terrain_chunk_props
        if not props.lod_collection:
            self.report({'ERROR'}, "No collection selected")
            return {'CANCELLED'}
        if not props.lod_levels:
            self.report({'ERROR'}, "LOD levels list is empty")
            return {'CANCELLED'}
        col = bpy.data.collections.get(props.lod_collection)
        if not col:
            self.report({'ERROR'}, "Collection not found")
            return {'CANCELLED'}
        meshes = [o for o in col.objects if o.type == 'MESH']
        if not meshes:
            self.report({'WARNING'}, "No mesh objects in collection")
            return {'CANCELLED'}
        for ob in meshes:
            ob.hide_set(True)
        for idx, src_ob in enumerate(meshes, start=1):
            lod0_name = f"{props.lod_pattern}_{idx}_LOD0"
            src_ob.name = lod0_name
            for lod_i, lvl in enumerate(props.lod_levels, start=1):
                new_ob = src_ob.copy()
                new_mesh = src_ob.data.copy()
                new_ob.data = new_mesh
                new_ob.name = f"{props.lod_pattern}_{idx}_LOD{lod_i}"
                col.objects.link(new_ob)
                mod = new_ob.modifiers.new(name="Decimate", type='DECIMATE')
                mod.ratio = lvl.ratio
                context.view_layer.objects.active = new_ob
                bpy.ops.object.modifier_apply(modifier=mod.name)
        self.report({'INFO'}, f"Generated LODs for {len(meshes)} chunks")
        return {'FINISHED'}

class LODAddOperator(Operator):
    bl_idname = "terrain.lod_add"
    bl_label = "Add LOD level"
    def execute(self, _c):
        bpy.context.scene.terrain_chunk_props.lod_levels.add()
        return {'FINISHED'}

class LODRemoveOperator(Operator):
    bl_idname = "terrain.lod_remove"
    bl_label = "Remove LOD level"
    def execute(self, _c):
        props = bpy.context.scene.terrain_chunk_props
        if props.lod_levels:
            props.lod_levels.remove(props.lod_levels_index)
            props.lod_levels_index = max(0, props.lod_levels_index - 1)
        return {'FINISHED'}

# ------------------------------------------------------------------
# Panel
# ------------------------------------------------------------------
class TerrainChunkPanel(Panel):
    bl_label = "Terrain Chunk Divider + LOD"
    bl_idname = "OBJECT_PT_terrain_chunk"
    bl_space_type = 'PROPERTIES'
    bl_region_type = 'WINDOW'
    bl_context = "object"

    def draw(self, context):
        layout = self.layout
        props = context.scene.terrain_chunk_props

        # Terrain division
        box = layout.box()
        box.label(text="Terrain Object", icon='MESH_DATA')
        row = box.row()
        row.prop(props, "terrain_object", text="")
        row.operator("terrain.select_terrain_object", icon='VIEWZOOM', text="")
        box = layout.box()
        box.label(text="Division Settings", icon='MOD_ARRAY')
        box.prop(props, "x_chunks")
        box.prop(props, "y_chunks")
        box = layout.box()
        box.label(text="Options", icon='PREFERENCES')
        box.prop(props, "rename_chunks")
        box.prop(props, "select_chunks")
        
        # New overlapping borders option
        box.prop(props, "use_overlapping_borders")
        if props.use_overlapping_borders:
            box.label(text="Warning: Original mesh will be deleted", icon='ERROR')
        
        layout.operator("terrain.divide_into_chunks", text="Divide Terrain", icon='MOD_EXPLODE')

        # Border mesh
        box = layout.box()
        box.label(text="Border Mesh", icon='EDGESEL')
        box.prop(props, "border_mesh_name")
        box.operator("terrain.create_border_mesh", text="Create Border Mesh", icon='MOD_EDGESPLIT')
        box.label(text="Select terrain chunks first", icon='INFO')

        # Normals transfer
        box = layout.box()
        box.label(text="Custom Normals Transfer", icon='NORMALS_FACE')
        row = box.row()
        row.prop(props, "normals_source_object", text="Source")
        row.operator("terrain.select_normals_source", icon='VIEWZOOM', text="")
        box.prop(props, "normals_collection", text="Target Collection")
        box.prop(props, "normals_modifier_name", text="Modifier Name")
        box.operator("terrain.add_normals_transfer", text="Add Normals Transfer", icon='MOD_DATA_TRANSFER')

        # LOD Generation
        box = layout.box()
        box.label(text="LOD Generation", icon='IMPORT')
        box.prop(props, "lod_collection", text="Collection")
        box.prop(props, "lod_pattern", text="Pattern")
        row = box.row()
        row.template_list("TERRAIN_UL_lod_levels", "", props, "lod_levels", props, "lod_levels_index", rows=3)
        col = row.column(align=True)
        col.operator("terrain.lod_add", icon='ADD', text="")
        col.operator("terrain.lod_remove", icon='REMOVE', text="")
        box.operator("terrain.generate_lods", text="Generate LODs", icon='MESH_ICOSPHERE')

# ------------------------------------------------------------------
# Registration
# ------------------------------------------------------------------
classes = (
    LODLevel,
    TerrainChunkProperties,
    TERRAIN_UL_lod_levels,
    DivideTerrainOperator,
    SelectTerrainObjectOperator,
    CreateBorderMeshOperator,
    AddNormalsTransferOperator,
    SelectNormalsSourceOperator,
    GenerateLODOperator,
    LODAddOperator,
    LODRemoveOperator,
    TerrainChunkPanel,
)

def register():
    for cls in classes:
        bpy.utils.register_class(cls)
    bpy.types.Scene.terrain_chunk_props = PointerProperty(type=TerrainChunkProperties)

def unregister():
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)
    del bpy.types.Scene.terrain_chunk_props

if __name__ == "__main__":
    register()