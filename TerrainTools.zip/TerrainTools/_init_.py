bl_info = {
    "name": "Terrain Chunk Divider",
    "author": "Your Name",
    "version": (1, 0),
    "blender": (3, 0, 0),
    "location": "Properties > Object",
    "description": "Divides terrain meshes into rectangular chunks based on world space coordinates",
    "warning": "",
    "doc_url": "",
    "category": "Object",
}

import bpy
import bmesh
from mathutils import Vector
from bpy.props import StringProperty, BoolProperty, IntProperty, FloatProperty, EnumProperty, PointerProperty, CollectionProperty
from bpy.types import PropertyGroup, UIList, Operator, Panel

# ==================== UTILITY FUNCTIONS ====================
def calculate_bounds(obj):
    """Calculate the bounding box dimensions of the object"""
    min_co = Vector((float('inf'),)*3)
    max_co = -min_co.copy()
    
    for v in obj.data.vertices:
        v_co = obj.matrix_world @ v.co
        min_co.x = min(min_co.x, v_co.x)
        min_co.y = min(min_co.y, v_co.y)
        min_co.z = min(min_co.z, v_co.z)
        max_co.x = max(max_co.x, v_co.x)
        max_co.y = max(max_co.y, v_co.y)
        max_co.z = max(max_co.z, v_co.z)
    
    return min_co, max_co

# ==================== PROPERTY GROUPS ====================
class TerrainChunkProperties(PropertyGroup):
    """Main properties for terrain chunk division"""
    
    object_name: StringProperty(
        name="Terrain Object",
        description="Name of the terrain object to divide"
    )
    
    x_chunks: IntProperty(
        name="X Chunks",
        default=2,
        min=1,
        max=100,
        description="Number of chunks along X axis"
    )
    
    y_chunks: IntProperty(
        name="Y Chunks",
        default=2,
        min=1,
        max=100,
        description="Number of chunks along Y axis"
    )
    
    rename_chunks: BoolProperty(
        name="Rename Chunks",
        default=True,
        description="Automatically name chunks with coordinates"
    )
    
    select_chunks: BoolProperty(
        name="Select Chunks",
        default=True,
        description="Select all chunks after division"
    )

# ==================== OPERATORS ====================
class DivideTerrainOperator(Operator):
    """Operator to divide terrain into chunks"""
    bl_idname = "terrain.divide_into_chunks"
    bl_label = "Divide Terrain"
    bl_options = {'REGISTER', 'UNDO'}
    
    def execute(self, context):
        props = context.scene.terrain_chunk_props
        
        obj = bpy.data.objects.get(props.object_name)
        if not obj:
            self.report({'ERROR'}, f"Object '{props.object_name}' not found!")
            return {'CANCELLED'}
        
        # Store original selection and active object
        original_selection = context.selected_objects.copy()
        original_active = context.view_layer.objects.active
        
        try:
            # Calculate terrain bounds
            min_co, max_co = calculate_bounds(obj)
            size = max_co - min_co
            chunk_size_x = size.x / props.x_chunks
            chunk_size_y = size.y / props.y_chunks
            
            # Create a bmesh for selection
            context.view_layer.objects.active = obj
            obj.select_set(True)
            bpy.ops.object.mode_set(mode='EDIT')
            bm = bmesh.from_edit_mesh(obj.data)
            bm.faces.ensure_lookup_table()
            
            chunk_objects = []
            
            # Process each chunk
            for i in range(props.x_chunks):
                for j in range(props.y_chunks):
                    # Calculate chunk bounds
                    x_min = min_co.x + i * chunk_size_x
                    x_max = x_min + chunk_size_x
                    y_min = min_co.y + j * chunk_size_y
                    y_max = y_min + chunk_size_y
                    
                    # Select faces within this chunk
                    bpy.ops.mesh.select_all(action='DESELECT')
                    for face in bm.faces:
                        face_center = obj.matrix_world @ face.calc_center_median()
                        if (x_min <= face_center.x <= x_max) and (y_min <= face_center.y <= y_max):
                            face.select = True
                    
                    # Separate the selection if any faces were selected
                    selected_faces = [f for f in bm.faces if f.select]
                    if selected_faces:
                        bmesh.update_edit_mesh(obj.data)
                        bpy.ops.mesh.separate(type='SELECTED')
                        bpy.ops.object.mode_set(mode='OBJECT')
                        
                        # Rename the new chunk
                        new_obj = context.selected_objects[-1]
                        if props.rename_chunks:
                            new_obj.name = f"{props.object_name}_chunk_{i}_{j}"
                        chunk_objects.append(new_obj)
                        
                        # Switch back to edit mode on original object
                        obj.select_set(True)
                        context.view_layer.objects.active = obj
                        bpy.ops.object.mode_set(mode='EDIT')
                        bm = bmesh.from_edit_mesh(obj.data)
                        bm.faces.ensure_lookup_table()
            
            # Clean up
            bpy.ops.object.mode_set(mode='OBJECT')
            
            # Select chunks if requested
            if props.select_chunks and chunk_objects:
                bpy.ops.object.select_all(action='DESELECT')
                for chunk in chunk_objects:
                    chunk.select_set(True)
                context.view_layer.objects.active = chunk_objects[0]
            
            self.report({'INFO'}, f"Terrain divided into {props.x_chunks * props.y_chunks} chunks")
            return {'FINISHED'}
            
        except Exception as e:
            # Restore original selection and active object
            bpy.ops.object.select_all(action='DESELECT')
            for obj in original_selection:
                obj.select_set(True)
            context.view_layer.objects.active = original_active
            
            self.report({'ERROR'}, f"Operation failed: {str(e)}")
            return {'CANCELLED'}

class SelectTerrainObjectOperator(Operator):
    """Operator to select the terrain object from the scene"""
    bl_idname = "terrain.select_object"
    bl_label = "Select Object"
    
    def execute(self, context):
        props = context.scene.terrain_chunk_props
        
        # Deselect all objects first
        bpy.ops.object.select_all(action='DESELECT')
        
        # Try to select the object by name
        obj = bpy.data.objects.get(props.object_name)
        if obj:
            obj.select_set(True)
            context.view_layer.objects.active = obj
            self.report({'INFO'}, f"Selected object: {props.object_name}")
        else:
            self.report({'WARNING'}, f"Object '{props.object_name}' not found!")
        
        return {'FINISHED'}

# ==================== PANELS ====================
class TerrainChunkPanel(Panel):
    """Main panel for terrain chunk division"""
    bl_label = "Terrain Chunk Divider"
    bl_idname = "OBJECT_PT_terrain_chunk"
    bl_space_type = 'PROPERTIES'
    bl_region_type = 'WINDOW'
    bl_context = "object"
    
    def draw(self, context):
        layout = self.layout
        props = context.scene.terrain_chunk_props
        
        # Object selection
        box = layout.box()
        box.label(text="Terrain Object", icon='MESH_DATA')
        row = box.row()
        row.prop(props, "object_name", text="")
        row.operator("terrain.select_object", icon='VIEWZOOM', text="")
        
        # Chunk settings
        box = layout.box()
        box.label(text="Division Settings", icon='MOD_ARRAY')
        box.prop(props, "x_chunks")
        box.prop(props, "y_chunks")
        
        # Options
        box = layout.box()
        box.label(text="Options", icon='PREFERENCES')
        box.prop(props, "rename_chunks")
        box.prop(props, "select_chunks")
        
        # Execute button
        layout.operator("terrain.divide_into_chunks", 
                      text="Divide Terrain", 
                      icon='MOD_EXPLODE')

# ==================== REGISTRATION ====================
classes = (
    TerrainChunkProperties,
    DivideTerrainOperator,
    SelectTerrainObjectOperator,
    TerrainChunkPanel,
)

def register():
    for cls in classes:
        bpy.utils.register_class(cls)
    
    # Register scene properties
    bpy.types.Scene.terrain_chunk_props = PointerProperty(type=TerrainChunkProperties)

def unregister():
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)
    
    # Clean up scene properties
    del bpy.types.Scene.terrain_chunk_props

if __name__ == "__main__":
    register()